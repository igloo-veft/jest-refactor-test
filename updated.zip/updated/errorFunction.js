const errorFunction = () => {
  if (true) {
    throw new Error('You need to mock me');
  }
  return true;
};
export default errorFunction;
